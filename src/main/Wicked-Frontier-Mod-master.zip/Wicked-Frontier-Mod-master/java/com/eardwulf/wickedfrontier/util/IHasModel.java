package com.eardwulf.wickedfrontier.util;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;

public interface IHasModel 
{
	public void registerModels();

}
